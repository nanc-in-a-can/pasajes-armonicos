import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import oscP5.*; 
import netP5.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class pasajesArmonicos extends PApplet {





//gui
ControlP5 cp5;
Slider2D  sliderXY;
Slider    sliderZ;

//osc
OscP5 oscP5;
NetAddress myRemoteLocation;

//ip values
String strIP = "127.0.0.1";
String strPort = "32000";

//slider vaues
float sliderPrevX = 0.0f;
float sliderPrevY = 0.0f;
float sliderPrevZ = 0.0f;

float sliderCurrX = 0.0f;
float sliderCurrY = 0.0f;
float sliderCurrZ = 0.0f;

public void setup() {
  
  

  PFont font = createFont("arial", 12);

  //osc
  oscP5 = new OscP5(this, 12000);
  myRemoteLocation = new NetAddress(strIP, Integer.parseInt(strPort));

  cp5 = new ControlP5(this);

  sliderXY = cp5.addSlider2D("xy")
    .setPosition(30, 40)
    .setSize(150, 150)
    .setMinMax(0.0f, 0.0f, 1.0f, 1.0f)
    .setValue(0.5f, 0.5f)
    //.disableCrosshair()
    ;

  sliderZ = cp5.addSlider("z")
    .setPosition(30, 250)
    .setRange(0, 1)
    .setSize(150, 20)
    ;

  ///////////////////////////////////////////////////////

  cp5.addTextlabel("OSC Message")
    .setText("OSC Message")
    .setPosition(250, 30)
    .setColorValue(0xffffffff);

  cp5.addTextfield("ip")
    .setPosition(250, 60)
    .setSize(150, 20)
    .setAutoClear(false)
    .setValue(strIP)
    .setColor(color(255, 0, 0));

  cp5.addTextfield("port")
    .setPosition(250, 110)
    .setSize(150, 20)
    .setValue(strPort)
    .setAutoClear(false);
}


public void ip(String strValue) {
  strIP = strValue;
  myRemoteLocation = new NetAddress(strIP, Integer.parseInt(strPort));
  println(strIP+ " "+strPort);
}

public void port(String strValue) {
  strPort = strValue;
  myRemoteLocation = new NetAddress(strIP, Integer.parseInt(strPort));
  println(strIP+ " "+strPort);
}


public void draw() {
  background(0);

  sliderPrevX = sliderCurrX;
  sliderPrevY = sliderCurrY;
  sliderPrevZ = sliderCurrZ;
  
  sliderCurrX = sliderXY.getArrayValue()[0];
  sliderCurrY = sliderXY.getArrayValue()[1];
  sliderCurrZ = sliderZ.getValue();
  
  if (sliderPrevX != sliderCurrX || sliderPrevY != sliderCurrY || sliderPrevZ != sliderCurrZ) {
    sendValues("dirxyz", sliderCurrX, sliderCurrY, sliderCurrZ);
    println("sent values "+ sliderCurrX+" "+sliderCurrY+" "+sliderCurrZ);
  }
  
  text("/dirxyz", 250, 180);
  text("X: "+sliderCurrX, 260, 200);
  text("Y: "+sliderCurrY, 260, 220);
  text("Z: "+sliderCurrZ, 260, 240);
}

public void sendValues(String msg, float x, float y, float z) {
  /* in the following different ways of creating osc messages are shown by example */
  OscMessage myMessage = new OscMessage(msg);

  myMessage.add(x);
  myMessage.add(y);
  myMessage.add(z);

  /* send the message */
  oscP5.send(myMessage, myRemoteLocation);
}
  public void settings() {  size(500, 300);  smooth(16); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "pasajesArmonicos" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
